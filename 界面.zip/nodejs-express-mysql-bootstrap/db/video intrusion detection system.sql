/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 80011
Source Host           : localhost:3306
Source Database       : video intrusion detection system

Target Server Type    : MYSQL
Target Server Version : 80011
File Encoding         : 65001

Date: 2021-01-27 06:05:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `intrusionrecords`
-- ----------------------------
DROP TABLE IF EXISTS `intrusionrecords`;
CREATE TABLE `intrusionrecords` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL,
  `image` text NOT NULL,
  `objectclass` text,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of intrusionrecords
-- ----------------------------
INSERT INTO `intrusionrecords` VALUES ('1', '2021-01-21 11:15:08', '1.jpg', 'human');
INSERT INTO `intrusionrecords` VALUES ('2', '2021-01-22 11:39:55', '2.jpg', 'cat');
INSERT INTO `intrusionrecords` VALUES ('3', '2021-01-23 09:43:03', '3.jpg', 'human');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `state` int(11) DEFAULT '1',
  `userclass` int(11) DEFAULT '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', 'admin', '1', '1');
INSERT INTO `user` VALUES ('2', '123456', '123456', '1', '0');
INSERT INTO `user` VALUES ('3', '111', '111', '1', '0');
INSERT INTO `user` VALUES ('4', '222', '222', '0', '1');
INSERT INTO `user` VALUES ('6', '231', '111', '0', '0');
