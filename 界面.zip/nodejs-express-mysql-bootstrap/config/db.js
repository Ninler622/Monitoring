// 导入数据库模块

const mysql = require("mysql");

// 设置数据库连接属性

let connect = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "",
    database: "video intrusion detection system",
    port: "3306",
});

// 开始连接数据库
connect.connect();

// 抛出模块

module.exports = connect;