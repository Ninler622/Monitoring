1、存放数据库的配置

安装数据库命令
    #cnpm install mysql

2、存放网站系统信息文件
