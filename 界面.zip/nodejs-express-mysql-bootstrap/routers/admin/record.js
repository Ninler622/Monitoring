let express = require("express");

let router = new express.Router();

//导入数据库模块
const mysql = require("../../config/db.js");

//导入时间格式化
const moment = require("moment");

// 导入分页方法
const page = require("../../common/page.js");

function checkTime(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

function timeFormat(time) {
    var date = new Date(time);
    return (
        date.getFullYear() +
        "-" +
        (date.getMonth() + 1) +
        "-" +
        date.getDate() +
        " " +
        checkTime(date.getHours()) +
        ":" +
        checkTime(date.getMinutes()) +
        ":" +
        checkTime(date.getSeconds())
    );
}

router.get("/", function(req, res, next) {
    // 第一步：获取页面,URL上的数据，如果URL上有p带了数据，取得该p的数值，否则取1
    let p = req.query.p ? req.query.p : 1;
    // 默认每页展示数据个数
    let size = 5;
    //接收检索数据
    let search = req.query.search ? req.query.search : ""; //获取点击提交按钮提交的输入框里面的数据

    // 计算总数据
    mysql.query(
        "select count(*) tot from intrusionrecords where objectclass like ? ", ["%" + search + "%"],
        function(err, data) {
            if (err) {
                res.send(err);
            } else {
                let tot = data[0].tot;
                let fpage = page(tot, p, size);
                // // 计算总页数:总数据/每页显示的个数，多出来的当一页处理
                mysql.query(
                    "select * from intrusionrecords where objectclass like ?  limit ?,?", ["%" + search + "%", fpage.start, fpage.size],
                    function(err, data) {
                        if (err) {
                            res.send(err);
                        } else {
                            for (var i = 0; i < data.length; i++) {
                                data[i].time = timeFormat(data[i].time);
                            }
                            res.render("admin/record/index.html", {
                                data: data,
                                search: search,
                                show: fpage.show,
                            });
                        }
                    }
                );
            }
        }
    );
});

// 用户添加页面
router.get("/add", function(req, res, next) {
    res.render("admin/record/add");
});

// 用户添加操作
router.post("/add", function(req, res, next) {
    let { time, image, objectclass } = req.body;

    mysql.query(
        "insert into intrusionrecords(time, image, objectclass) values(?,?,?)", [time, image, objectclass],
        function(err, data) {
            if (err) {
                res.send(err);
            } else {
                if (data.affectedRows == 1) {
                    res.send(
                        "<script>alert('入侵记录添加成功');location.href = '/admin/record'</script>"
                    );
                } else {
                    res.send("<script>alert('入侵记录添加失败');history.go(-1)</script>");
                }
            }
        }
    );
});

module.exports = router;