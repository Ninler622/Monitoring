let express = require("express");

let router = new express.Router();

//导入数据库模块
const mysql = require("../../config/db.js");

//导入时间格式化
const moment = require("moment");

// 导入分页方法
const page = require("../../common/page.js");

function query(sqlc, sql, res, selectstate, selectclass) {
    mysql.query(sqlc, function(err, data) {
        if (err) {
            res.send(err);
        } else {
            let size = 5;
            let tot = data[0].tot;
            let fpage = page(tot, 1, size);
            mysql.query(sql, [fpage.start, fpage.size], function(err, data) {
                if (err) {
                    res.send(err);
                } else {
                    res.render("admin/user/index.html", {
                        data: data,
                        search: "",
                        state: selectstate,
                        userclass: selectclass,
                        show: fpage.show,
                    });
                }
            });
        }
    });
}

router.get("/", function(req, res, next) {
    // 第一步：获取页面,URL上的数据，如果URL上有p带了数据，取得该p的数值，否则取1
    let p = req.query.p ? req.query.p : 1;
    // 默认每页展示数据个数
    let size = 5;
    //接收检索数据
    let search = req.query.search ? req.query.search : ""; //获取点击提交按钮提交的输入框里面的数据
    let { state, userclass } = req.query;

    // 计算总数据
    mysql.query(
        "select count(*) tot from user where username like ? ", ["%" + search + "%"],
        function(err, data) {
            if (err) {
                return err;
            } else {
                let tot = data[0].tot;
                let fpage = page(tot, p, size);
                // // 计算总页数:总数据/每页显示的个数，多出来的当一页处理
                mysql.query(
                    "select * from user where username like ?  limit ?,?", ["%" + search + "%", fpage.start, fpage.size],
                    function(err, data) {
                        if (err) {
                            return err;
                        } else {
                            res.render("admin/user/index.html", {
                                data: data,
                                search: search,
                                show: fpage.show,
                                state: state,
                                userclass: userclass,
                            });
                        }
                    }
                );
            }
        }
    );
});

router.post("/", function(req, res, next) {
    let { selectstate, selectclass } = req.body;
    console.log(selectstate, selectclass);
    if (selectstate == "请选择") {
        selectstate = undefined;
    } else if (selectclass == "请选择") {
        selectclass = undefined;
    }

    let sqlc1 = `select count(*) tot from user where userclass=${selectclass}`;
    let sql1 = `select * from user where userclass=${selectclass} limit ?,?`;
    let sqlc2 = `select count(*) tot from user where state=${selectstate}`;
    let sql2 = `select * from user where state=${selectstate} limit ?,?`;
    let sqlc3 = `select count(*) tot from user where state=${selectstate} and userclass=${selectclass}`;
    let sql3 = `select * from user where state=${selectstate} and userclass=${selectclass} limit ?,?`;

    if (selectstate == undefined && selectclass != undefined) {
        query(sqlc1, sql1, res, selectstate, selectclass);
    } else if (selectstate != undefined && selectclass == undefined) {
        query(sqlc2, sql2, res, selectstate, selectclass);
    } else {
        query(sqlc3, sql3, res, selectstate, selectclass);
    }
});

// 用户添加页面
router.get("/add", function(req, res, next) {
    res.render("admin/user/add");
});

// 用户添加操作
router.post("/add", function(req, res, next) {
    // 获取上传的数据
    let { username, password, repassword, state, userclass } = req.body;
    if (username) {
        if (password) {
            if (password === repassword) {
                // 查询数据库是否存在同名用户
                mysql.query(
                    "select * from user where username = ?", [username],
                    function(err, data) {
                        if (err) {
                            return err;
                        } else {
                            if (data.length == 0) {
                                // 执行数据库插入操作
                                mysql.query(
                                    "insert into user(username,password,state,userclass) values(?,?,?,?)", [username, password, state, userclass],
                                    function(err, data) {
                                        if (err) {
                                            return err;
                                        } else {
                                            if (data.affectedRows == 1) {
                                                res.send(
                                                    "<script>alert('用户添加成功');location.href = '/admin/user'</script>"
                                                );
                                            } else {
                                                res.send(
                                                    "<script>alert('用户添加失败');history.go(-1)</script>"
                                                );
                                            }
                                        }
                                    }
                                );
                            } else {
                                res.send(
                                    "<script>alert('该用户已被注册');history.go(-1)</script>"
                                );
                            }
                        }
                    }
                );
            } else {
                res.send(
                    "<script>alert('两次输入的密码不一致');history.go(-1)</script>"
                );
            }
        } else {
            res.send("<script>alert('请输入密码');history.go(-1)</script>");
        }
    } else {
        res.send("<script>alert('请输入用户名');history.go(-1)</script>");
    }
});

// 无刷新删除管理员数据
router.get("/ajax_del", function(req, res, next) {
    let uid = req.query.uid;
    mysql.query(`delete from user where uid = ${uid}`, function(err, data) {
        if (err) {
            return err;
        } else {
            if (data.affectedRows == 1) {
                res.send("1");
            } else {
                res.send("0");
            }
        }
    });
});

// 修改
router.get("/edit", function(req, res, next) {
    let uid = req.query.uid;
    mysql.query("select * from user where uid = " + uid, function(err, data) {
        if (err) {
            return err;
        } else {
            res.render("admin/user/edit.html", { data: data[0] });
        }
    });
});

router.post("/edit", function(req, res, next) {
    let { uid, username, password, state, userclass } = req.body;
    mysql.query(
        `update user set username = '${username}',password ='${password}',state=${state},userclass=${userclass} where uid = ${uid}`,
        function(err, data) {
            if (err) {
                return err;
            } else {
                if (data.affectedRows == 1) {
                    res.send(
                        "<script>alert('修改成功');location.href='/admin/user'</script>"
                    );
                } else {
                    res.send("<script>alert('修改失败');history.go(-1)</script>");
                }
            }
        }
    );
});

module.exports = router;